from django.shortcuts import render

# Create your views here.
from django.http import HttpResponse
from django.shortcuts import redirect
from django.urls import reverse
import APP.models as models

import environ
import os

def landing_page(request):
    return render(request, 'landing_page.html')

def login(request):
    return render(request,'login_page.html')


def register(request):
    return render(request, "create_account.html")


def doregister(request):
    data = {}

    data['email'] = request.POST.get('email')
    data['password'] = request.POST.get('pwd')
    client_confirm_password = request.POST.get('cpwd')
    data['firstname'] = request.POST.get('fname')
    data['lastname'] = request.POST.get('lname')
    data['gender'] = request.POST.get('cgender',"unknown")
    data['age_group'] = request.POST.get('age-group',"unknown")
    data['country'] = request.POST.get('country',"unknown")
    data['state'] = request.POST.get('state',"unknown")
    data['HEQ'] = request.POST.get('education',"unknown")
    data['how_hear'] = request.POST.get('how-hear',"unknown")

    if not data['password'] == client_confirm_password:
        return render(request, 'create_account.html', {'errmsg': 'Password confirms failure!'})
    print(data)
    try:
        user_email = models.Client.objects.filter(email = data['email'])
    except Exception as e:
        user_email = None
    if user_email:
       return render(request, 'login.html', {'errmsg': 'E-mail is already registered!'})

    models.Client.objects.create(**data)

    client = models.Client.objects.get(email=data['email'])

    request.session['id'] = client.id

    return render(request, 'setup_survey.html')

def org_info(request):

    print(request.session.get('id'))

    data = {}

    data['id'] = request.session.get('id')
    data['oname'] = request.POST.get('Oname')
    data['otype'] = request.POST.get('Otype')
    data['industry'] = request.POST.get('Indus')
    data['number'] = request.POST.get('NoE')
    data['challenge'] = request.POST.get('Wchallenge')
    #data['Wchallenget'] = request.POST.get('Wchallenget',"unknown")
    data['relunits'] = request.POST.get('relevantO')
    #data['relunits1'] = request.POST.get('relevant1')

    print(data)

    models.Org.objects.create(**data)

    return render(request,'Link.html')


def dologin(request):
    #return HttpResponse("1")

    try:
        # 根据账号获取登录者信息
        client_email = request.POST.get('emaila')
        client_psw = request.POST.get('psw')

        #return HttpResponse(client_psw)

        client = models.Client.objects.get(email=client_email)

        request.session['id'] = client.id

        print(request.session.get('id'))

        if client.password == client_psw:
            '''
            request.session['id'] = client.id
            org = models.Org.objects.get(id=(str)(client.id))
            print(org)
            '''
            dic = data_analysis(request.session.get('id'))
            print(dic)

            return render(request, "survey_result_organisation.html", dic)
            #return org_info(request)
            #return HttpResponse(str(os.path.join(APPS_DIR('static'),'css')))
            #return redirect(reverse("setup_survey.html"))
        else:
            context = {'info': '登录密码错误！'}
    except:
        context = {'info': '登录账号错误！'}
    return render(request, "login_page.html", context)

def dashboard(request):
    '''
    data = {}
    client = models.Client.objects.get(id=request.session.get('id'))
    org = models.Org.objects.get(id=request.session.get('id'))

    data['username'] = client.email
    data['orgname'] = org.oname

    print(data)
    '''
    return render(request, 'survey_result_organisation.html')

def part1(request):
    print(request.session.get('id'))
    return render(request, "survey_page_part1.html")


def part2(request):
    print(request.session.get('id'))
    data = {}

    data['age'] = request.POST.get('age')
    data['gender'] = request.POST.get('gender')
    data['role'] = request.POST.get('role')
    data['time'] = request.POST.get('hlong')
    data['local'] = request.POST.get('locate')
    data['team'] = request.POST.get('wteam')
    data['positive_change'] = request.POST.get('change')
    data['championed_change'] = request.POST.get('last6m')
    data['trust'] = request.POST.get('trust')

    print(data)

    request.session['p1_age'] = request.POST.get('age')
    request.session['p1_gender'] = request.POST.get('gender')
    request.session['p1_role'] = request.POST.get('role')
    request.session['p1_time'] = request.POST.get('hlong')
    request.session['p1_local'] = request.POST.get('locate')
    request.session['p1_team'] = request.POST.get('wteam')
    request.session['p1_positive_change'] = request.POST.get('change')
    request.session['p1_championed_change'] = request.POST.get('last6m')
    request.session['p1_trust'] = request.POST.get('trust')

    #models.Part1.objects.create(**data)

    return render(request, "survey_page_part2.html")


def part3(request):
    print(request.session.get('id'))

    data = {}

    data['one'] = request.POST.get('1')
    data['two_one'] = request.POST.get('2_1')
    data['two_two'] = request.POST.get('2_2')
    data['two_three'] = request.POST.get('2_3')
    data['two_four'] = request.POST.get('2_4')
    data['two_five'] = request.POST.get('2_5')
    data['two_six'] = request.POST.get('2_6')
    data['two_seven'] = request.POST.get('2_7')
    data['three_one'] = request.POST.get('3_1')
    data['three_two'] = request.POST.get('3_2')
    data['four'] = request.POST.get('4')
    data['five_one'] = request.POST.get('5_1')
    data['five_two'] = request.POST.get('5_2')
    data['five_three'] = request.POST.get('5_3')
    data['five_four'] = request.POST.get('5_4')
    data['six'] = request.POST.get('6')
    data['seven_one'] = request.POST.get('7_1')
    data['seven_two'] = request.POST.get('7_2')
    data['seven_three'] = request.POST.get('7_3')
    data['seven_four'] = request.POST.get('7_4')
    data['seven_five'] = request.POST.get('7_5')
    data['eight_one'] = request.POST.get('8_1')
    data['eight_two'] = request.POST.get('8_2')
    data['eight_three'] = request.POST.get('8_3')
    data['eight_four'] = request.POST.get('8_4')
    data['eight_five'] = request.POST.get('8_5')

    print(data)

    request.session['p2_one'] = request.POST.get('1')
    request.session['p2_two_one'] = request.POST.get('2_1')
    request.session['p2_two_two'] = request.POST.get('2_2')
    request.session['p2_two_three'] = request.POST.get('2_3')
    request.session['p2_two_four'] = request.POST.get('2_4')
    request.session['p2_two_five'] = request.POST.get('2_5')
    request.session['p2_two_six'] = request.POST.get('2_6')
    request.session['p2_two_seven'] = request.POST.get('2_7')
    request.session['p2_three_one'] = request.POST.get('3_1')
    request.session['p2_three_two'] = request.POST.get('3_2')
    request.session['p2_four'] = request.POST.get('4')
    request.session['p2_five_one'] = request.POST.get('5_1')
    request.session['p2_five_two'] = request.POST.get('5_2')
    request.session['p2_five_three'] = request.POST.get('5_3')
    request.session['p2_five_four'] = request.POST.get('5_4')
    request.session['p2_six'] = request.POST.get('6')
    request.session['p2_seven_one'] = request.POST.get('7_1')
    request.session['p2_seven_two'] = request.POST.get('7_2')
    request.session['p2_seven_three'] = request.POST.get('7_3')
    request.session['p2_seven_four'] = request.POST.get('7_4')
    request.session['p2_seven_five'] = request.POST.get('7_5')
    request.session['p2_eight_one'] = request.POST.get('8_1')
    request.session['p2_eight_two'] = request.POST.get('8_2')
    request.session['p2_eight_three'] = request.POST.get('8_3')
    request.session['p2_eight_four'] = request.POST.get('8_4')
    request.session['p2_eight_five'] = request.POST.get('8_5')

    #models.Part2.objects.create(**data)

    return render(request, "survey_page_part3.html")

def individual(request):
    print(request.session.get('id'))
    data = {}

    question = {}

    data['one'] = request.POST.get('1')
    data['two'] = request.POST.get('2')
    data['three'] = request.POST.get('3')
    data['four'] = request.POST.get('4')
    data['five'] = request.POST.get('5')
    data['six'] = request.POST.get('6')
    data['seven'] = request.POST.get('7')
    data['eight'] = request.POST.get('8')
    data['nine'] = request.POST.get('9')
    data['ten'] = request.POST.get('10')
    data['eleven'] = request.POST.get('11')
    data['twelve'] = request.POST.get('12')
    data['thirteen'] = request.POST.get('13')
    data['fourteen'] = request.POST.get('14')
    data['fifteen'] = request.POST.get('15')
    data['sixteen'] = request.POST.get('16')
    data['seventeen'] = request.POST.get('17')
    data['eighteen'] = request.POST.get('18')
    data['nineteen'] = request.POST.get('19')
    data['twenty'] = request.POST.get('20')
    data['twentyone'] = request.POST.get('21')
    data['twentytwo'] = request.POST.get('22')
    data['twentythree'] = request.POST.get('23')
    data['twentyfour'] = request.POST.get('24')
    data['twentyfive'] = request.POST.get('25')
    data['twentysix'] = request.POST.get('26')
    data['twentyseven'] = request.POST.get('27')
    data['twentyeight'] = request.POST.get('28')
    data['twentynine'] = request.POST.get('29')
    data['thirty'] = request.POST.get('30')
    data['thirtyone'] = request.POST.get('31')
    data['thirtytwo'] = request.POST.get('32')
    data['thirtythree'] = request.POST.get('33')
    data['thirtyfour'] = request.POST.get('34')
    data['thirtyfive'] = request.POST.get('35')
    data['thirtysix'] = request.POST.get('36')
    data['thirtyseven'] = request.POST.get('37')
    data['thirtyeight'] = request.POST.get('38')
    data['thirtynine'] = request.POST.get('39')

    print(data)

    question['oid'] = request.session.get('id')
    question['p1_age'] = request.session.get('p1_age')
    question['p1_gender'] = request.session.get('p1_gender')
    question['p1_role'] = request.session.get('p1_role')
    question['p1_time'] = request.session.get('p1_time')
    question['p1_local'] = request.session.get('p1_local')
    question['p1_team'] = request.session.get('p1_team')
    question['p1_positive_change'] = request.session.get('p1_positive_change')
    question['p1_championed_change'] = request.session.get('p1_championed_change')
    question['p1_trust'] = request.session.get('p1_trust')
    question['p2_one'] = request.session.get('p2_one')
    question['p2_two_one'] = request.session.get('p2_two_one')
    question['p2_two_two'] = request.session.get('p2_two_two')
    question['p2_two_three'] = request.session.get('p2_two_three')
    question['p2_two_four'] = request.session.get('p2_two_four')
    question['p2_two_five'] = request.session.get('p2_two_five')
    question['p2_two_six'] = request.session.get('p2_two_six')
    question['p2_two_seven'] = request.session.get('p2_two_seven')
    question['p2_three_one'] = request.session.get('p2_three_one')
    question['p2_three_two'] = request.session.get('p2_three_two')
    question['p2_four'] = request.session.get('p2_four')
    question['p2_five_one'] = request.session.get('p2_five_one')
    question['p2_five_two'] = request.session.get('p2_five_two')
    question['p2_five_three'] = request.session.get('p2_five_three')
    question['p2_five_four'] = request.session.get('p2_five_four')
    question['p2_six'] = request.session.get('p2_six')
    question['p2_seven_one'] = request.session.get('p2_seven_one')
    question['p2_seven_two'] = request.session.get('p2_seven_two')
    question['p2_seven_three'] = request.session.get('p2_seven_three')
    question['p2_seven_four'] = request.session.get('p2_seven_four')
    question['p2_seven_five'] = request.session.get('p2_seven_five')
    question['p2_eight_one'] = request.session.get('p2_eight_one')
    question['p2_eight_two'] = request.session.get('p2_eight_two')
    question['p2_eight_three'] = request.session.get('p2_eight_three')
    question['p2_eight_four'] = request.session.get('p2_eight_four')
    question['p2_eight_five'] = request.session.get('p2_eight_five')
    question['p3_one'] = request.POST.get('1')
    question['p3_two'] = request.POST.get('2')
    question['p3_three'] = request.POST.get('3')
    question['p3_four'] = request.POST.get('4')
    question['p3_five'] = request.POST.get('5')
    question['p3_six'] = request.POST.get('6')
    question['p3_seven'] = request.POST.get('7')
    question['p3_eight'] = request.POST.get('8')
    question['p3_nine'] = request.POST.get('9')
    question['p3_ten'] = request.POST.get('10')
    question['p3_eleven'] = request.POST.get('11')
    question['p3_twelve'] = request.POST.get('12')
    question['p3_thirteen'] = request.POST.get('13')
    question['p3_fourteen'] = request.POST.get('14')
    question['p3_fifteen'] = request.POST.get('15')
    question['p3_sixteen'] = request.POST.get('16')
    question['p3_seventeen'] = request.POST.get('17')
    question['p3_eighteen'] = request.POST.get('18')
    question['p3_nineteen'] = request.POST.get('19')
    question['p3_twenty'] = request.POST.get('20')
    question['p3_twentyone'] = request.POST.get('21')
    question['p3_twentytwo'] = request.POST.get('22')
    question['p3_twentythree'] = request.POST.get('23')
    question['p3_twentyfour'] = request.POST.get('24')
    question['p3_twentyfive'] = request.POST.get('25')
    question['p3_twentysix'] = request.POST.get('26')
    question['p3_twentyseven'] = request.POST.get('27')
    question['p3_twentyeight'] = request.POST.get('28')
    question['p3_twentynine'] = request.POST.get('29')
    question['p3_thirty'] = request.POST.get('30')
    question['p3_thirtyone'] = request.POST.get('31')
    question['p3_thirtytwo'] = request.POST.get('32')
    question['p3_thirtythree'] = request.POST.get('33')
    question['p3_thirtyfour'] = request.POST.get('34')
    question['p3_thirtyfive'] = request.POST.get('35')
    question['p3_thirtysix'] = request.POST.get('36')
    question['p3_thirtyseven'] = request.POST.get('37')
    question['p3_thirtyeight'] = request.POST.get('38')
    question['p3_thirtynine'] = request.POST.get('39')

    print(question)

    #models.Part3.objects.create(**data)

    models.Question.objects.create(**question)

    dic = {}

    engage_style = [0.0, 0.0, 0.0, 0.0]
    motivations = [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0]

    motivations[0] = (int)(request.session.get('p2_two_one'))
    motivations[1] = (int)(request.session.get('p2_two_two'))
    motivations[2] = (int)(request.session.get('p2_two_three'))
    motivations[3] = (int)(request.session.get('p2_two_four'))
    motivations[4] = (int)(request.session.get('p2_two_five'))
    motivations[5] = (int)(request.session.get('p2_two_six'))
    motivations[6] = (int)(request.session.get('p2_two_seven'))


    engage_style = p3_analys(request.POST.get('1'),engage_style)
    engage_style = p3_analys(request.POST.get('2'), engage_style)
    engage_style = p3_analys(request.POST.get('3'), engage_style)
    engage_style = p3_analys(request.POST.get('4'), engage_style)
    engage_style = p3_analys(request.POST.get('5'),engage_style)
    engage_style = p3_analys(request.POST.get('6'), engage_style)
    engage_style = p3_analys(request.POST.get('7'),engage_style)
    engage_style = p3_analys(request.POST.get('8'), engage_style)
    engage_style = p3_analys(request.POST.get('9'), engage_style)
    engage_style = p3_analys(request.POST.get('10'), engage_style)
    engage_style = p3_analys(request.POST.get('11'), engage_style)
    engage_style = p3_analys(request.POST.get('12'), engage_style)
    engage_style = p3_analys(request.POST.get('13'), engage_style)
    engage_style = p3_analys(request.POST.get('14'), engage_style)
    engage_style = p3_analys(request.POST.get('15'), engage_style)
    engage_style = p3_analys(request.POST.get('16'), engage_style)
    engage_style = p3_analys(request.POST.get('17'), engage_style)
    engage_style = p3_analys(request.POST.get('18'), engage_style)
    engage_style = p3_analys(request.POST.get('19'), engage_style)
    engage_style = p3_analys(request.POST.get('20'), engage_style)
    engage_style = p3_analys(request.POST.get('21'), engage_style)
    engage_style = p3_analys(request.POST.get('22'), engage_style)
    engage_style = p3_analys(request.POST.get('23'), engage_style)
    engage_style = p3_analys(request.POST.get('24'), engage_style)
    engage_style = p3_analys(request.POST.get('25'), engage_style)
    engage_style = p3_analys(request.POST.get('26'), engage_style)
    engage_style = p3_analys(request.POST.get('27'), engage_style)
    engage_style = p3_analys(request.POST.get('28'), engage_style)
    engage_style = p3_analys(request.POST.get('29'), engage_style)
    engage_style = p3_analys(request.POST.get('30'), engage_style)
    engage_style = p3_analys(request.POST.get('31'), engage_style)
    engage_style = p3_analys(request.POST.get('32'), engage_style)
    engage_style = p3_analys(request.POST.get('33'), engage_style)
    engage_style = p3_analys(request.POST.get('34'), engage_style)
    engage_style = p3_analys(request.POST.get('35'), engage_style)
    engage_style = p3_analys(request.POST.get('36'), engage_style)
    engage_style = p3_analys(request.POST.get('37'), engage_style)
    engage_style = p3_analys(request.POST.get('38'), engage_style)
    engage_style = p3_analys(request.POST.get('39'), engage_style)

    dic['engage_style'] = engage_style
    dic['motivations'] = motivations

    print(dic)

    return render(request, "individual_report.html",dic)


def data_analysis(para):
    print(para)
    all_id = models.Question.objects.all().values('id')

    dic = {}
    gender = [0, 0, 0, 0]
    age = [0, 0, 0, 0, 0, 0, 0]
    role = [0, 0, 0]
    tenure = [0, 0, 0, 0]
    engage_style = [0.0, 0.0, 0.0, 0.0]
    motivations = [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0]

    for id_num in all_id:
        personal_answer = models.Question.objects.get(id=id_num['id'])

        #if personal_answer.oid == "1":
        if personal_answer.oid == str(para):
            if personal_answer.p1_gender == '1':
                gender[0] += 1
            elif personal_answer.p1_gender == '2':
                gender[1] += 1
            elif personal_answer.p1_gender == '3':
                gender[2] += 1
            elif personal_answer.p1_gender == '4':
                gender[3] += 1

            if personal_answer.p1_age == "Less than 20":
                age[0] += 1
            elif personal_answer.p1_age == "20 - 29":
                age[1] += 1
            elif personal_answer.p1_age == "30 - 39":
                age[2] += 1
            elif personal_answer.p1_age == "40 - 49":
                age[3] += 1
            elif personal_answer.p1_age == "50 - 59":
                age[4] += 1
            elif personal_answer.p1_age == "60 - 69":
                age[5] += 1
            elif personal_answer.p1_age == "More than 70":
                age[6] += 1

            if personal_answer.p1_role == '1':
                role[0] += 1
            elif personal_answer.p1_role == '2':
                role[1] += 1
            elif personal_answer.p1_role == '3':
                role[2] += 1

            if personal_answer.p1_time == "1 - 2 years":
                tenure[0] += 1
            elif personal_answer.p1_time == "2 - 5 years":
                tenure[1] += 1
            elif personal_answer.p1_time == " 5 - 10 years":
                tenure[2] += 1
            elif personal_answer.p1_time == "more than 10 years":
                tenure[3] += 1

            engage_style = p3_analys(personal_answer.p3_one,engage_style)
            engage_style = p3_analys(personal_answer.p3_two, engage_style)
            engage_style = p3_analys(personal_answer.p3_three, engage_style)
            engage_style = p3_analys(personal_answer.p3_four, engage_style)
            engage_style = p3_analys(personal_answer.p3_five,engage_style)
            engage_style = p3_analys(personal_answer.p3_six, engage_style)
            engage_style = p3_analys(personal_answer.p3_seven,engage_style)
            engage_style = p3_analys(personal_answer.p3_eight, engage_style)
            engage_style = p3_analys(personal_answer.p3_nine, engage_style)
            engage_style = p3_analys(personal_answer.p3_ten, engage_style)
            engage_style = p3_analys(personal_answer.p3_eleven, engage_style)
            engage_style = p3_analys(personal_answer.p3_twelve, engage_style)
            engage_style = p3_analys(personal_answer.p3_thirteen, engage_style)
            engage_style = p3_analys(personal_answer.p3_fourteen, engage_style)
            engage_style = p3_analys(personal_answer.p3_fifteen, engage_style)
            engage_style = p3_analys(personal_answer.p3_sixteen, engage_style)
            engage_style = p3_analys(personal_answer.p3_seventeen, engage_style)
            engage_style = p3_analys(personal_answer.p3_eighteen, engage_style)
            engage_style = p3_analys(personal_answer.p3_nineteen, engage_style)
            engage_style = p3_analys(personal_answer.p3_twenty, engage_style)
            engage_style = p3_analys(personal_answer.p3_twentyone, engage_style)
            engage_style = p3_analys(personal_answer.p3_twentytwo, engage_style)
            engage_style = p3_analys(personal_answer.p3_twentythree, engage_style)
            engage_style = p3_analys(personal_answer.p3_twentyfour, engage_style)
            engage_style = p3_analys(personal_answer.p3_twentyfive, engage_style)
            engage_style = p3_analys(personal_answer.p3_twentysix, engage_style)
            engage_style = p3_analys(personal_answer.p3_twentyseven, engage_style)
            engage_style = p3_analys(personal_answer.p3_twentyeight, engage_style)
            engage_style = p3_analys(personal_answer.p3_twentynine, engage_style)
            engage_style = p3_analys(personal_answer.p3_thirty, engage_style)
            engage_style = p3_analys(personal_answer.p3_thirtyone, engage_style)
            engage_style = p3_analys(personal_answer.p3_thirtytwo, engage_style)
            engage_style = p3_analys(personal_answer.p3_thirtythree, engage_style)
            engage_style = p3_analys(personal_answer.p3_thirtyfour, engage_style)
            engage_style = p3_analys(personal_answer.p3_thirtyfive, engage_style)
            engage_style = p3_analys(personal_answer.p3_thirtysix, engage_style)
            engage_style = p3_analys(personal_answer.p3_thirtyseven, engage_style)
            engage_style = p3_analys(personal_answer.p3_thirtyeight, engage_style)
            engage_style = p3_analys(personal_answer.p3_thirtynine, engage_style)

            motivations[0] += (int)(personal_answer.p2_two_one)
            motivations[1] += (int)(personal_answer.p2_two_two)
            motivations[2] += (int)(personal_answer.p2_two_three)
            motivations[3] += (int)(personal_answer.p2_two_four)
            motivations[4] += (int)(personal_answer.p2_two_five)
            motivations[5] += (int)(personal_answer.p2_two_six)
            motivations[6] += (int)(personal_answer.p2_two_seven)

    for i in range(0, len(motivations), 1):
        motivations[i] = (float)(motivations[i]/len(all_id))

    for i in range(0,len(engage_style),1):
        engage_style[i] = (float)(engage_style[i]/len(all_id))

    dic['gender'] = gender
    dic['age'] = age
    dic['role'] = role
    dic['tenure'] = tenure
    dic['engage_style'] = engage_style
    dic['motivations'] = motivations
    return dic

def p3_analys(p3_, engage_style):
    if p3_ == 's':
        engage_style[0] += 1
    elif p3_ == 'k':
        engage_style[1] += 1
    elif p3_ == 'a':
        engage_style[2] += 1
    elif p3_ == 'e':
        engage_style[3] += 1
    return  engage_style