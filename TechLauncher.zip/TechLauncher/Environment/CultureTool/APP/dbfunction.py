
#datadic = {}, model = Model.model
def create(datadic, model):
    model.objects.create(**datadic)

def delete(model):
    model.objects.filter(user='yangmv').delete()

def update(model):
    model.objects.filter(user='yangmv').update(pwd='520')

#user = {"today": datetime.datetime.now(),"id":myID,"name":myName}
#c = Context(user)
#return HttpResponse(t.render(c))