"""CultureTool URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/2.2/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path
from django.conf.urls import include
from django.conf.urls import url
from APP import views as index

urlpatterns = [
    #path('admin/', admin.site.urls),
    #path('', index.client),
    path('', index.landing_page, name="landing_page"),
    path('login', index.login, name="login"),
    path('dologin', index.dologin, name="dologin"),
    path('register', index.register, name="register"),
    path('doregister', index.doregister, name="doregister"),
    path('org_info', index.org_info, name="org_info"),
    path('dashboard',index.dashboard, name="dashboard"),
    path('part1',index.part1,name="part1"),
    path('part2',index.part2,name="part2"),
    path('part3',index.part3,name="part3"),
    path('individual',index.individual,name="individual"),


    #url(r'^$', admin.site.urls),
    #url(r'^login$', index.login, name="login"),
    #url(r'^dologin$', index.dologin, name="dologin"),
    #url(r'^homepage$', index.homepage, name="homepage"),

    #path('', index.index),
]
