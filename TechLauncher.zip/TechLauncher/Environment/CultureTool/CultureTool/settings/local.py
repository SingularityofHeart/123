from .base import *

DEBUG = env.bool('DJANGO_DEBUG', default=True)